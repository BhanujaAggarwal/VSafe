from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.shortcuts import render

from blog.models.post import Post


def safemap(request, username=None):

    return render(request, 'blog/safemap.html')
