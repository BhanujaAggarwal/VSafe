Semotions (share your emotions)
A fully functional django based website. Pythonanywhere ready.
Website wherein users will be able to post their sentiments/feelings anonymously and can get emotional support from other users.
Features :-

Login Sign-Up
Users can post on the website
Users can update & delete their posts
Users can view & reply to other posts

You can go for a demo on: https://thesecret.pythonanywhere.com/blog/
